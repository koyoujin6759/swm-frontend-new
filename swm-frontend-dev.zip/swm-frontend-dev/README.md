Study-With-Me Frontend
=============